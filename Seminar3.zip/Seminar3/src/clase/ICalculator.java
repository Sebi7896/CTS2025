package clase;

public interface ICalculator<T extends Angajat> {

     calculSalariu(T angajat) {
        return 0;
    }
}
