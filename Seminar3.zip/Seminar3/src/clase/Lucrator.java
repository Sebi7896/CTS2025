package clase;

public class Lucrator extends Angajat{

    CalculatorLucrator calculator = new CalculatorLucrator();
    public Lucrator(int id, String nume, float salariulDeBaza) {
        super(id, nume, salariulDeBaza);
    }
}
