package clase;

public class CalculatorManager implements ICalculator<Manager>{

    public float calculSalariu(Manager angajat) {
        return -1;
    }
}
