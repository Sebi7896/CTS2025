package clase;

public class CalculatorLucrator implements ICalculator<Lucrator>{
    public float calculSalariu(Lucrator angajat) {
        return 0;
    }

}
